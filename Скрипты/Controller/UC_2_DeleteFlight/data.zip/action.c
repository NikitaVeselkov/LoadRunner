Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://localhost:8090/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("login");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:8090");

	lr_think_time(8);

	web_submit_data("login.pl", 
		"Action=http://localhost:8090/WebTours/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8090/WebTours/nav.pl?in=home", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=134890.730336168zQDittVpQtVzzzzHtVzDApzfVzf", ENDITEM, 
		"Name=username", "Value=Nikita", ENDITEM, 
		"Name=password", "Value=nikita", ENDITEM, 
		"Name=login.x", "Value=60", ENDITEM, 
		"Name=login.y", "Value=13", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_start_transaction("goToIItinerary");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(8);

	web_url("Itinerary Button", 
		"URL=http://localhost:8090/WebTours/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8090/WebTours/nav.pl?page=menu&in=home", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("goToIItinerary",LR_AUTO);

	lr_start_transaction("deleteAllFlight");

	web_add_header("Origin", 
		"http://localhost:8090");

	lr_think_time(19);

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:8090/WebTours/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8090/WebTours/itinerary.pl", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flightID", "Value=0-789-NV", ENDITEM, 
		"Name=removeAllFlights.x", "Value=34", ENDITEM, 
		"Name=removeAllFlights.y", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		LAST);

	lr_end_transaction("deleteAllFlight",LR_AUTO);

	lr_think_time(27);

	lr_start_transaction("logout");

	web_url("SignOff Button", 
		"URL=http://localhost:8090/WebTours/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:8090/WebTours/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}